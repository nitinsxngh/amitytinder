import React, { useState, useMemo, useRef, useEffect } from "react";
import TinderCard from "react-tinder-card";
import { FaTimes, FaUndo, FaHeart } from "react-icons/fa";
import MatchPopup from "./MatchPopup"; // Import MatchPopup
import "./Swipe.css";

const defaultProfilePicture = "https://via.placeholder.com/150"; // Default image URL

function Advanced() {
  const [users, setUsers] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [lastDirection, setLastDirection] = useState();
  const [showMatchPopup, setShowMatchPopup] = useState(false); // Show match popup
  const [matchUserName, setMatchUserName] = useState(""); // Matched user name
  const currentIndexRef = useRef(currentIndex);

  const childRefs = useMemo(
    () =>
      Array(users.length)
        .fill(0)
        .map(() => React.createRef()),
    [users]
  );

  useEffect(() => {
    const fetchUsers = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        console.error("User is not authenticated.");
        return;
      }

      try {
        const response = await fetch("http://localhost:5008/api/auth/all-users", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.error || "Failed to fetch users.");
        }

        const userData = await response.json();
        setUsers(
          userData.map((user) => ({
            id: user._id || `${user.name}-${Math.random()}`,
            name: user.name || "Anonymous",
            url: user.profilePicture || defaultProfilePicture,
            gender: user.gender || "Not specified",
          }))
        );
        setCurrentIndex(userData.length - 1);
      } catch (err) {
        console.error("Error fetching user data:", err);
      }
    };

    fetchUsers();
  }, []);

  const updateCurrentIndex = (val) => {
    setCurrentIndex(val);
    currentIndexRef.current = val;
  };

  const canGoBack = currentIndex < users.length - 1;
  const canSwipe = currentIndex >= 0;

  const swiped = async (direction, targetUserName, index) => {
    setLastDirection(direction);

    try {
      const token = localStorage.getItem("token");
      const targetUserId = users[index]?.id;

      if (token && targetUserId) {
        const response = await fetch("http://localhost:5008/api/auth/swipe", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ targetUserId, direction }),
        });

        const data = await response.json();
        if (data.mutual) {
          setMatchUserName(targetUserName);
          setShowMatchPopup(true);
        }
      }
    } catch (err) {
      console.error("Error sending swipe action:", err);
    }

    updateCurrentIndex(index - 1);
  };

  const outOfFrame = (name, idx) => {
    console.log(`${name} (${idx}) left the screen!`, currentIndexRef.current);
    currentIndexRef.current >= idx && childRefs[idx].current.restoreCard();
  };

  const swipe = async (dir) => {
    if (canSwipe && currentIndex < users.length) {
      await childRefs[currentIndex].current.swipe(dir);
    }
  };

  const goBack = async () => {
    if (!canGoBack) return;
    const newIndex = currentIndex + 1;
    updateCurrentIndex(newIndex);
    await childRefs[newIndex].current.restoreCard();
  };

  return (
    <div id="swipe-root">
      {/* Dynamic Island-like Container for the "Likes" label */}
      <div className="dynamic-island">
        <span className="dynamic-text">Amity</span>
      </div>
      <br></br>
      <br></br>
      {/* If no users, don't show anything except the heading */}
      {users.length === 0 ? (
        <></>
      ) : (
        <>
          {/* Match Popup */}
          <MatchPopup
            visible={showMatchPopup}
            userName={matchUserName}
            onClose={() => setShowMatchPopup(false)}
          />

          <div className="cardContainer">
            {users.map((user, index) => (
              <TinderCard
                ref={childRefs[index]}
                className="swipe"
                key={user.id}
                onSwipe={(dir) => swiped(dir, user.name, index)}
                onCardLeftScreen={() => outOfFrame(user.name, index)}
              >
                <div
                  style={{ backgroundImage: `url(${user.url})` }}
                  className="card"
                >
                  <h3>{user.name} {user.gender.charAt(0)}</h3>
                </div>
              </TinderCard>
            ))}
          </div>

          <div className="buttons">
            <button onClick={() => swipe("left")}>
              <FaTimes />
            </button>
            <button onClick={() => goBack()}>
              <FaUndo />
            </button>
            <button onClick={() => swipe("right")}>
              <FaHeart />
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Advanced;
