import React from "react";
import { useNavigate } from "react-router-dom";
import "./Swipe.css";

const MatchPopup = ({ visible, userName, onClose }) => {
  const navigate = useNavigate();

  if (!visible) return null;

  const handleSendMessage = () => {
    onClose(); // Close the popup
    navigate(`/messages/${userName}`); // Navigate to the message page with the user's name
  };

  return (
    <div className="match-popup-overlay">
      <div className="match-popup">
        <h2>🎉 It's a Match! 🎉</h2>
        <p>You matched with {userName}!</p>
        <div className="popup-buttons">
          <button className="message-btn" onClick={handleSendMessage}>
            Message
          </button>
          <button className="close-btn" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default MatchPopup;
