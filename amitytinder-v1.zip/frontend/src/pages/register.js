import RegisterForm from "../components/Onboard/RegisterForm";


const Register = () => {

  return (
     <div>
      <RegisterForm />
    </div>
  );
};

export default Register;