import LikedBy from '../components/Likes/LikedBy';
import BottomNav from "../BottomNav/BottomNav";

function likes() {
  return (
    <div>
      <LikedBy />
      <BottomNav />
    </div>
  );
}

export default likes;
