import MatchesList from "../components/Messages/MatchesList";
import BottomNav from "../BottomNav/BottomNav";
import { useState } from "react";

const Messages = () => {
  const [loading, setLoading] = useState(true);

  const handleMatchesLoaded = () => {
    setLoading(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {loading && (
        <div style={{ textAlign: 'center', marginTop: '20px' }}>
          <p>Loading matches...</p>
        </div>
      )}
      <MatchesList onLoad={handleMatchesLoaded} />
      <BottomNav />
    </div>
  );
};

export default Messages;
