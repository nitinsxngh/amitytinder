import React from "react";
import StepForm from "../components/StepForm/StepForm";

const Form = () => {
  return (
    <div>
      <StepForm />
    </div>
  );
};

export default Form;
