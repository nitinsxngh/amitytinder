import LoginForm from "../components/Onboard/LoginForm";


const Login = () => {

  return (
     <div>
      <LoginForm />
    </div>
  );
};

export default Login;