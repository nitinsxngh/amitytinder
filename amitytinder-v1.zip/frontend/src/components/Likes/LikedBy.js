import React, { useState, useEffect } from 'react';
import './LikedBy.css'; // Ensure your styles are correctly applied

const LikedBy = () => {
  // States for handling data, loading, and errors
  const [likedByProfiles, setLikedByProfiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchLikedByProfiles = async () => {
      try {
        // Retrieve token from localStorage for authentication
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:5008/api/auth/liked-by', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        // Check if response is valid and handle different scenarios
        if (!response.ok) {
          if (response.status === 404) {
            setLikedByProfiles([]); // No data found, set empty array
          } else {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
          }
        } else {
          const data = await response.json();
          setLikedByProfiles(data.length ? data : []); // Set data or empty array if no data
        }
      } catch (err) {
        console.error('Error fetching liked-by profiles:', err.message);
        setError('Failed to fetch liked-by profiles. Please try again later.');
      } finally {
        setLoading(false); // Set loading to false once request completes
      }
    };

    fetchLikedByProfiles(); // Fetch liked profiles on component mount
  }, []); // Empty dependency array means this effect runs once on mount

  // Conditional rendering based on loading, error, or no data
  if (loading) {
    return <div className="loading-message">Loading...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  if (!likedByProfiles.length) {
    return (
      <div className="empty-state-message">
        {/* Show the image when no profiles liked */}
        <img 
          src="img/13.png" 
          alt="No likes yet" 
          className="empty-state-image"
        />
        <p>Your profile is waiting to be discovered. Keep shining!</p>
      </div>
    );
  }
  

  return (
    <>
      {/* Dynamic Island-like Container for the "Likes" label */}
      <div className="dynamic-island">
        <span className="dynamic-text">Likes</span>
      </div>

      {/* Container for the liked-by profiles */}
      <div className="liked-by-container">
        <div className="liked-by-grid">
          {/* Mapping through liked profiles and rendering each profile */}
          {likedByProfiles.map(profile => (
            <div className="liked-by-card" key={profile._id}>
              <img
                src={profile.profilePicture || 'https://via.placeholder.com/150'}
                alt="User profile"
                className="profile-picture"
                onContextMenu={(e) => e.preventDefault()}  // Disable right-click on image
              />
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default LikedBy;
