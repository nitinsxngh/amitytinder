const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    },
    password: {
      type: String,
      required: true,
      minlength: 6,
    },
    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      minlength: 3,
    },
    name: {
      type: String,
      trim: true,
    },
    dob: {
      type: Date,
    },
    gender: {
      type: String,
      enum: ['Male', 'Female', 'Other'],
    },
    interestedIn: {
      type: String,
      enum: ['Male', 'Female', 'Both'],
    },
    bio: {
      type: String,
      maxlength: 250,
      default: '',
    },
    profilePicture: {
      type: String,
      default: '', // URL for the user's profile picture
    },
    university: {
      type: String,
      trim: true,
      default: '',
    },
    swipeLimit: {
      type: Number,
      default: 10, // Daily swipe limit
    },
    spinLimit: {
      type: Number,
      default: 5, // Daily spin limit (custom feature)
    },
    liked: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ], // List of user IDs liked by this user
    disliked: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ], // List of user IDs disliked by this user
    matches: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ], // List of matched user IDs
    otp: {
      type: String,
      default: '', // For email/phone verification
    },
    status: {
      type: String,
      enum: ['active', 'inactive', 'banned'],
      default: 'inactive',
    },
    isVerified: {
      type: Boolean,
      default: false, // Email or account verification status
    },
    pinnedMatches: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
    ], // List of pinned user IDs
  },
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
